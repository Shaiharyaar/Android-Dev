package com.example.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class HintActivity extends AppCompatActivity {
    private Button showHintB;
    private Button backB;
    private TextView hint;
    private TextView ques;
    private Bundle extra;
    private int charge=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hint);
        hint = findViewById(R.id.hint_);
        ques = findViewById(R.id.quesTest_);
        showHintB = findViewById(R.id.hintB2);
        backB = findViewById(R.id.back_);
        extra = getIntent().getExtras();
        //creating a clicklistener for hint button
        showHintB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //charging the user for pressing hint button
                charge = -5;
                //showing the hint
                ques.setText("Aap ki hint ab neeche show ki jaa ri hai :)");
                hint.setText(extra.getString("hint"));
                //disabing the hint button
                showHintB.setEnabled(false);
            }
        });
        //creating a clicklistener for backButton
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //creating intent
                Intent intent = new Intent();
                //puttin data in intent
                intent.putExtra("score",String.valueOf(charge));
                //setting result for the parent activity
                setResult(Activity.RESULT_OK,intent);
                finish();
            }
        });

    }

}

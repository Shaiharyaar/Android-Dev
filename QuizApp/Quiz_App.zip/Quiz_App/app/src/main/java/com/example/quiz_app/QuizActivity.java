package com.example.quiz_app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class QuizActivity extends AppCompatActivity {
    public TextView playerName;
    public TextView Score;
    public Button nextB;
    public Button prevB;
    public Button trueB;
    public Button falseB;
    private Button hint;
    private int score = 0;
    private String category;
    private String age;
    private Bundle extra;
    int count=0;
    private int curr_Q = 0;
    private boolean gave_answer[] = {false,false,false,false,false};
    private TextView questions;
    private int CorrectAnswer = 0;
    private ArrayList<Test> TEST = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        playerName = findViewById(R.id.player_);
        Score = findViewById(R.id.score_);
        questions = findViewById(R.id.questionText);
        nextB = findViewById(R.id.next_);
        nextB.setText("Next");
        prevB = findViewById(R.id.prev_);
        prevB.setText("Prev");
        trueB = findViewById(R.id.true_);
        falseB = findViewById(R.id.false_);
        hint = findViewById(R.id.hint_);


        //Checking which category was selected in the previous Activity
        extra = getIntent().getExtras();
        category = extra.getString("category");
        if(category.equals("History")){
            generateHistoryTest();
        }else if(category.equals("Science")){
            generateScienceTest();
        }else if(category.equals("General")){
            generateGeneralTest();
        }

        playerName.setText("Player: "+ extra.getString("name"));
        age = extra.getString("age");
        Score.setText("Score: "+ String.valueOf(score));

    }
    //Setting ClickMethod for True and false button
    public void onTrueFalseClick(View v) {
        Toast toast;

        //taking first question of the selected category
        boolean correct = this.TEST.get(this.curr_Q).getAnswer();
        //Taking the value of which button is pressed
        boolean userChoice = Boolean.parseBoolean(((Button) v).getText().toString());
        gave_answer[curr_Q] = true;
        //Comparing the actual answer with the selected choice
        if (correct == userChoice) {
            //Updating number of correct answers
            CorrectAnswer++;
            //updating how many questions have been answered
            count++;
            //updating Scoreboard
            score = score+10;
            Score.setText("Score: "+ String.valueOf(score));

            //Showing the user that the answer was correct or not
            toast = Toast.makeText(getApplicationContext(),"Sahi jawab hai",Toast.LENGTH_SHORT);
            toast.show();
        } else {
            count++;
            toast = Toast.makeText(getApplicationContext(),"Ghalat Jawab hai",Toast.LENGTH_SHORT);
            toast.show();
        }
        //checking whether all the questions have been answered or not
        if(count==5 && curr_Q==4){
            nextB.setText("Result");
        }
            //Disabling the buttons
            trueB.setEnabled(false);
            falseB.setEnabled(false);
            hint.setEnabled(false);
    }

    public void onNextClick(View v) {
        Toast toast;
        //checking how many questions are answered and taking actions in accordance to that
        if (curr_Q<3) {
            //updating question number
            this.curr_Q++;
            //checking if the question is answered or not
            alreadyAnswered();
            //showing the next question
            String next_Q = this.TEST.get(this.curr_Q).getQuestion();
            this.questions.setText(next_Q);
        }else if(curr_Q == 3){
            this.curr_Q++;
            //checking if all the questions are answered or not
            if(count==5 && curr_Q==4){
                //updating the text on next button to result
                nextB.setText("Result");
            }

            alreadyAnswered();

            String next_Q = this.TEST.get(this.curr_Q).getQuestion();
            this.questions.setText(next_Q);

        }
        //checking if user is on last question and next button has converted to Result
        else if(curr_Q == 4 && nextB.getText().equals("Result")){
            //Creating intent and passing data
            Intent intent5 = new Intent(this, ResultActivity.class);
            intent5.putExtra("name", extra.getString("name") );
            intent5.putExtra("age", age );
            intent5.putExtra("score", String.valueOf(score));
            intent5.putExtra("count", String.valueOf(CorrectAnswer));
            intent5.putExtra("category", category );
            //passing the result for parent activity to the next activity
            intent5.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
            startActivity(intent5);
            //finishing current activity
            finish();
        }
        //checking if user is at the last question and hasn't answered all of them
        else if(curr_Q==4 && !nextB.getText().equals("Result")){
            alreadyAnswered();
            toast = Toast.makeText(getApplicationContext(),"You have reached the last Question.", Toast.LENGTH_SHORT);
            toast.show();
        }

    }

    public void onPrevClick(View v) {
        Toast toast;
        nextB.setText("Next");
        if (curr_Q>0) {
            this.curr_Q--;
            alreadyAnswered();
            String next_Q = this.TEST.get(this.curr_Q).getQuestion();
            this.questions.setText(next_Q);
        }
        //keeping the user in bounds
        else if(curr_Q == 0){
            alreadyAnswered();
            toast = Toast.makeText(getApplicationContext(),"You have reached the first Question.",
                    Toast.LENGTH_SHORT);
            toast.show();

        }

    }
    public void onHintClick(View v){
        Intent intent = new Intent(this, HintActivity.class);
        intent.putExtra("hint", this.TEST.get(curr_Q).getHint());
        //passing the intent with a hint to get result
        startActivityForResult(intent,3);
    }

    //GENERATING QUIZES
    void generateHistoryTest(){
        this.TEST.add(new Test("Meaning of Pakistan is Holy Land.",true,"try thinking the meaning of pak"));
        questions.setText(this.TEST.get(0).getQuestion());
        this.TEST.add(new Test("The first governer general of pakistam was Ayub khan",false,"do you reallu need a hint?"));
        this.TEST.add(new Test("In 1992, Pakistan won the World Cup Match",true,"Are you even a pakistani3?"));
        this.TEST.add(new Test("General Parvez Musharaf was born in Delhi",true,"its not where you think it is."));
        this.TEST.add(new Test("Pakistan was created by NKJ",false,"*Bald pissed guy meme*?"));
    }
    void generateScienceTest(){
        this.TEST.add(new Test("Electrons are larger than molecules.",false,"really??"));
        questions.setText(this.TEST.get(0).getQuestion());
        this.TEST.add(new Test("Sharks are mammals.",false,"What is a mammal to you?"));
        this.TEST.add(new Test("Venus is the closest planet to the Sun.",false,"Do you need a ruler? -__-"));
        this.TEST.add(new Test("The study of plants is known as botany.",true,"this might be true."));
        this.TEST.add(new Test("Herbivores eat meat.",false,"Lions ain't no herbivores"));
    }
    void generateGeneralTest(){
        this.TEST.add(new Test("Number 10 come after 8.",false,"seven eight nine."));
        questions.setText(this.TEST.get(0).getQuestion());
        this.TEST.add(new Test("Baby frogs are called tidepods.",false,"Have you even done a laundry?"));
        this.TEST.add(new Test("Jeeps are known as a ship of the desert.",false,"Does a jeep look like a ship to you?"));
        this.TEST.add(new Test("There are 26 letters in English Alphabets",true,"Don't tell me you don't know A B C"));
        this.TEST.add(new Test("Mount Everest is really tall.",true,"Are you dumb?"));
    }
    //Check for whether the question was answered or not.
    //Enabling or Disabling some buttons depending on the answer
    private void alreadyAnswered() {
        if(!gave_answer[curr_Q]) {
            trueB.setEnabled(true);
            falseB.setEnabled(true);
            hint.setEnabled(true);

        }else{
            trueB.setEnabled(false);
            falseB.setEnabled(false);
            hint.setEnabled(false);
        }
    }
    //Getting result from child activity
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //checking to see if the request code matches
        if(requestCode== 3){
            //updating the score
            score = score + Integer.parseInt(data.getStringExtra("score"));
            Score.setText("Score: "+ String.valueOf(score));
        }
    }

}

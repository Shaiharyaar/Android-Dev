package com.example.quiz_app;

public class Test {

    private String Question;
    private boolean Answer;
    private String Hint;

    public Test(String Que, boolean Ans, String hint) {
        this.Question = Que;
        this.Answer = Ans;
        this.Hint = hint;
    }

    public String getHint() {

        return this.Hint;
    }

    public String getQuestion() {
        return this.Question;
    }

    public boolean getAnswer() {

        return this.Answer;
    }

}

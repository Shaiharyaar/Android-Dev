package com.example.quiz_app;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EnterQuiz extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private TextView name;
    private TextView age;
    private EditText name_T;
    private EditText age_T;
    private Spinner categoriesList;
    private String Selected_Category = "History";
    private Button next_btn;
    private Button back_btn;
    private Toast toast;
    private ArrayAdapter<CharSequence> listAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_quiz);
        name = (TextView)findViewById(R.id.name_);
        age = (TextView)findViewById(R.id.age_text);
        name_T = findViewById(R.id.name_);
        age_T = findViewById(R.id.age_text);
        categoriesList = findViewById(R.id.spinner);
        //Putting arraylist of categories from string.xml to the spinner
        listAdapter = ArrayAdapter.createFromResource(this,
                R.array.categories,android.R.layout.simple_spinner_item);
        //Specifying how our spinner would show resources
        listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoriesList.setAdapter(listAdapter);
        categoriesList.setOnItemSelectedListener(this);
        next_btn = (Button)findViewById(R.id.next_);
        back_btn = (Button)findViewById(R.id.backbtn);
    }

    public void OnClick(View v){
        //Checking which button is pressed
        if(v.getId() == next_btn.getId()){
            //Checking if the fields are filled correctly and if yes then move toward the next Activity
            if((name.getText().toString().equals(""))){
                toast = Toast.makeText(getApplicationContext(),"Name field is empty",Toast.LENGTH_SHORT);
                toast.show();
            }else if(!(name.getText().toString().matches("^[a-zA-Z]*$"))){
                name.setText("");
                name.setHint("Enter your Name");
                toast = Toast.makeText(getApplicationContext(),"Please use only alphabets", Toast.LENGTH_SHORT);
                toast.show();
            }else if(age.getText() == null){
                toast = Toast.makeText(getApplicationContext(),"Enter your Age",Toast.LENGTH_SHORT);
                toast.show();
            }else if(Integer.parseInt(age.getText().toString())>150 || Integer.parseInt(age.getText().toString())<3){
                age.setText(null);
                age.setHint("Enter your AGE");
                toast = Toast.makeText(getApplicationContext(),"Please enter your ACTUAL age",Toast.LENGTH_SHORT);
                toast.show();
            }else{
                Intent intent = new Intent(this,QuizActivity.class);
                intent.putExtra("name",name.getText().toString());
                intent.putExtra("age",age.getText().toString());
                intent.putExtra("category",Selected_Category);
                startActivityForResult(intent,1);

            }
        }else if(v.getId() == back_btn.getId()){
            //finishing the child(this activity) of previous activity(MainActivity)
            finish();
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(categoriesList.getSelectedItem().toString().equals("History")){
            Selected_Category = "History";
        }else if(categoriesList.getSelectedItem().toString().equals("Science")){
            Selected_Category = "Science";
        }else if(categoriesList.getSelectedItem().toString().equals("General")){
            Selected_Category = "General";
        }else{
            Selected_Category = "";
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            //getting values back and prefilling the fields

        }

    }
}

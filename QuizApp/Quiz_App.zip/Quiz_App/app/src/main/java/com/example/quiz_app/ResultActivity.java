package com.example.quiz_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    private TextView name;
    private TextView score;
    private TextView category;
    private Button again_B;
    private Bundle extra;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        extra = getIntent().getExtras();

        again_B  = findViewById(R.id.retake_);
        //getting values from parents and displaying them on this activity
        name = findViewById(R.id.name_);
        name.setText("Name: "+ extra.getString("name")+"  ---  Age: "+extra.getString("age"));
        score = findViewById(R.id.score_);
        score.setText("Score: "+ extra.getString("score")+"\n"+
                extra.getString("count")+" out of 5 Correct Answers.");
        category = findViewById(R.id.category_);
        category.setText("Category Selected: "+ extra.getString("category"));

    }
    void onClick(View v){
        if(v.getId() == again_B.getId()){
            //Sending data back to parent
            Intent intent = new Intent();
            intent.putExtra("name", extra.getString("name"));
            intent.putExtra("age", extra.getString("age"));
            intent.putExtra("category", extra.getString("category"));
            setResult(Activity.RESULT_OK, intent);
            finish();
        }

    }
}

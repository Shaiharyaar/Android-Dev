package com.example.oddeven;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private TextView oddeven;
    private Button odd;
    private Button even;
    private Button continueB;
    private Random random = new Random();
    private int rand_1;
    private int score = 0;
    private int count = 0;
    private Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        oddeven = findViewById(R.id.oddeven_ID);
        odd = findViewById(R.id.odd_ID);
        even = findViewById(R.id.even_ID);
        continueB = findViewById(R.id.cont_ID);

        continueB.setEnabled(false);
        continueB.setVisibility(View.INVISIBLE);
        getRand();
        oddeven.setText(String.valueOf(rand_1));
    }

    void getRand(){
        boolean check = true;
        while(check){
            rand_1 = random.nextInt(100);
            if(rand_1>1){
                check = false;
            }
        }
    }

    public void onODDclick(View v){

        if(count<5){
            count++;
            if(rand_1%2==0){
                score = score-1;
                toast = Toast.makeText(getApplicationContext(),"Wrong Answer", Toast.LENGTH_SHORT);
                toast.show();
            }else{
                score = score+1;
                toast = Toast.makeText(getApplicationContext(),"Correct.", Toast.LENGTH_SHORT);
                toast.show();
            }
            getRand();
            oddeven.setText(String.valueOf(rand_1));
        }else{
            odd.setEnabled(false);
            even.setEnabled(false);
            continueB.setVisibility(View.VISIBLE);
            continueB.setEnabled(true);
        }

    }
    public void onEVENclick(View v){

        if(count<5){
            count++;
            if(rand_1%2==0){
                score = score+1;
                toast = Toast.makeText(getApplicationContext(),"Correct.", Toast.LENGTH_SHORT);
                toast.show();

            }else{
                score = score-1;
                toast = Toast.makeText(getApplicationContext(),"Wrong Answer", Toast.LENGTH_SHORT);
                toast.show();
            }
            getRand();
            oddeven.setText(String.valueOf(rand_1));
        }else{
            odd.setEnabled(false);
            even.setEnabled(false);
            continueB.setVisibility(View.VISIBLE);
            continueB.setEnabled(true);
        }

    }
    public void contClick(View v){

        Intent intent = new Intent(this, resultAct.class);
        intent.putExtra("score", String.valueOf(score));
        startActivity(intent);
    }
}

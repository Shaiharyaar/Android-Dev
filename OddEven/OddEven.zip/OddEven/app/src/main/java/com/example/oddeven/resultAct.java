package com.example.oddeven;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class resultAct extends AppCompatActivity {
    private TextView score_;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        score_ = findViewById(R.id.score_T);
        Bundle ext = getIntent().getExtras();
        score_.setText(ext.getString("score")+" points");
    }
}

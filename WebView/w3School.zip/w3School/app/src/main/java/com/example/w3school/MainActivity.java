package com.example.w3school;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    public Spinner categoriesList;
    public Button launch;
    public int index;
    public String url[] = {"https://www.w3schools.com/html/default.asp", "https://www.w3schools.com/css/default.asp",
            "https://www.w3schools.com/bootstrap/bootstrap_ver.asp", "https://www.w3schools.com/colors/default.asp",
            "https://www.w3schools.com/icons/default.asp"};
    public String learnTopic = "https://www.w3schools.com/html/default.asp";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        categoriesList = findViewById(R.id.spinner);



        ArrayAdapter<CharSequence> listAdapter = ArrayAdapter.createFromResource(this,
                R.array.learning_resources,android.R.layout.simple_spinner_item);
        listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categoriesList.setAdapter(listAdapter);
        categoriesList.setOnItemSelectedListener(this);
        launch = findViewById(R.id.launch_);
        launch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, WebPageActivity.class);
                intent.putExtra("topic",learnTopic);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(categoriesList.getSelectedItem().toString().equals("HTML")){
                learnTopic = url[0];
                index = 0;
        }else if(categoriesList.getSelectedItem().toString().equals("CSS")){
                learnTopic = url[1];
                index = 1;
        }else if(categoriesList.getSelectedItem().toString().equals("Bootstrap")){
                learnTopic = url[2];
                index = 2;
        }else if(categoriesList.getSelectedItem().toString().equals("Colors")){
                learnTopic = url[3];
                index = 3;
        }else if(categoriesList.getSelectedItem().toString().equals("Icons")){
                learnTopic = url[4];
                index = 4;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    @Override
    public void onSaveInstanceState(Bundle onSaveState) {
        super.onSaveInstanceState(onSaveState);
        Log.i("Msg", "Saving State!");
        onSaveState.putInt("index", index);
    }
}
